
#pragma once

#include "sam.h"

#ifdef __cplusplus
extern "C"
{
#endif

    /* Returns a 32-bit true random number (NIST 800-22) */
    extern uint32_t tRandom(void);

    /* Fills passed byte array with 'n' true random bytes.
     * Maximum 'n' is 255.
     */
    extern void tRandomBytes(uint8_t *r, uint8_t n);

#ifdef __cplusplus
}
#endif
