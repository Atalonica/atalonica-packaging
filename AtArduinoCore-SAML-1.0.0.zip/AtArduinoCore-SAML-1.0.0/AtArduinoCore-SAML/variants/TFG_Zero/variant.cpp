/*
 * +------------+------------------+--------+-----------------+------------------------------------------------------------------------------------------------------------------
 * + Pin number + Physical PCB pin | IC PIN | Functionality   | Comments (* is for default peripheral in use)
 * +------------+------------------+--------+-----------------+------------------------------------------------------------------------------------------------------------------
 * |            | Digital          |        |                 | EIC / RSTC  |  ADC        AC     PTC          |  SERCOM          |  SERCOM-ALT      |  TC/TCC      |  TCC (ALT)
 * +------------+------------------+--------+-----------------+-------------+---------------------------------+------------------+------------------+--------------+-------------
 * | 0          | D0 RX            |  PA11  |  Serial0        | EXTINT[11]  |  AIN[19]           X[3],Y[9]    | *SERCOM0/PAD[3]  |  SERCOM2/PAD[3]  |  TCC1/WO[1]  |  TCC0/WO[3]
 * | 1          | D1 TX            |  PA10  |  Serial0        | EXTINT[10]  |  AIN[18]           X[2],y[8]    | *SERCOM0/PAD[2]  |  SERCOM2/PAD[2]  |  TCC1/WO[0]  |  TCC0/WO[2]
 * | 2          | D2               |  PA15  |  LED, PWM0_C5   | EXTINT[15]  |                                 |  SERCOM2/PAD[3]  |  SERCOM4/PAD[3]  |  TC4/WO[1]   |  TCC0/WO[5]
 * | 3          | DIO4 RX          |  PB23  |  RX, DIO4, Ser1 | EXTINT[7]   |                                 |                  | *SERCOM5/PAD[3]  |              |
 * | 4          | DIO3 TX          |  PB22  |  TX, DIO3, Ser1 | EXTINT[6]   |                                 |                  | *SERCOM5/PAD[2]  |              |
 * | 5          | DIO2             |  PA20  |  DIO2, PWM0_C6  | EXTINT[4]   |                    X[8]         |  SERCOM5/PAD[2]  |  SERCOM3/PAD[2]  |              |  TCC0/WO[6]
 * | 6          | DIO1             |  PA19  |  DIO1, PWM0_C3  | EXTINT[3]   |                    X[7]         |  SERCOM1/PAD[3]  |  SERCOM3/PAD[3]  |  TC4/WO[1]   |  TCC0/WO[3]
 * | 7          | SDA              |  PA22  |  SDA (crypto)   | EXTINT[6]   |                    X[10]        | *SERCOM3/PAD[0]  |  SERCOM5/PAD[0]  |  TC0/WO[0]   |  TCC0/WO[4]
 * | 8          | SCL              |  PA23  |  SCL (crypto)   | EXTINT[7]   |                    X[11]        | *SERCOM3/PAD[1]  |  SERCOM5/PAD[1]  |  TC0/WO[0]   |  TCC0/WO[5]
 * | 9          | SWIO             |  PA31  |  SWDIO  PWM1_C1 | EXTINT[11]  |                                 |                  |  SERCOM1/PAD[3]  |  TCC1/WO[1]  |
 * | 10         | SWCLK            |  PA30  |  SWCLK, PWM1_C0 | EXTINT[10]  |                                 |                  |  SERCOM1/PAD[2]  |  TCC1/WO[0]  |
 * | 11         | VBAT EN          |  PA06  |  VBAT_EN        | EXTINT[6]   |  AIN[6]    AIN[2]  Y[4]         |                  |  SERCOM0/PAD[2]  |  TCC1/WO[0]  |
 * +------------+------------------+--------+-----------------+-------------+---------------------------------+------------------+------------------+--------------+-------------
 * |            | Not accessible   |        |                 |             |                                 |                  |                  |              |
 * +------------+------------------+--------+-----------------+-------------+---------------------------------+------------------+------------------+--------------+-------------
 * | 12         |                  |  PA18  |  DIO0, PWM0_C2  | EXTINT[2]   |                    X[6]         |  SERCOM1/PAD[2]  |  SERCOM3/PAD[2]  |  TC4/WO[0]   |  TCC0/WO[2]
 * | 13         |                  |  PA08  |  RFM_CS,PWM1_C2 | NMI         |  AIN[16]           X[0],Y[6]    |  SERCOM0/PAD[0]  |  SERCOM2/PAD[0]  |  TCC0/WO[0]  |  TCC1/WO[2]
 * | 14         |                  |  PA09  |  RFM_RST,PWM1_C3| EXTINT[9]   |  AIN[17]           X[1],Y[7]    |  SERCOM0/PAD[1]  |  SERCOM2/PAD[1]  |  TCC0/WO[1]  |  TCC1/WO[3]
 * | 15         |                  |  PA13  |  MEM_CS,PWM0_C7 | EXTINT[13]  |                                 |  SERCOM2/PAD[1]  |  SERCOM4/PAD[1]  |  TCC2/WO[1]  |  TCC0/WO[7]
 * | 16         |                  |  PA14  |  MEM_EN,PWM0_C4 | EXTINT[14]  |                                 |  SERCOM2/PAD[2]  |  SERCOM4/PAD[2]  |  TC4/WO[0]   |  TCC0/WO[4]
 * | 17         |                  |  PA21  |  CRYPTO_EN      | EXTINT[5]   |                    X[9]         |  SERCOM5/PAD[3]  |  SERCOM3/PAD[3]  |              |  TCC0/WO[7]
 * | 18         |                  |  PA16  |  SDA (T&H)      | EXTINT[0]   |                    X[4]         | *SERCOM1/PAD[0]  |  SERCOM3/PAD[0]  |  TCC2/WO[0]  |  TCC0/WO[6]
 * | 19         |                  |  PA17  |  SCL (T&H)      | EXTINT[1]   |                    X[5]         | *SERCOM1/PAD[1]  |  SERCOM3/PAD[1]  |  TCC2/WO[1]  |  TCC0/WO[7]
 * +------------+------------------+--------+-----------------+-------------+---------------------------------+------------------+------------------+--------------+-------------
 * |            | Analog           |        |                 |             |                                 |                  |                  |              |
 * +------------+------------------+--------+-----------------+-------------+---------------------------------+------------------+------------------+--------------+-------------
 * | A0, 20     | A0 DAC           |  PA02  |  A0             | EXTINT[2]   | *AIN[0]            Y[0]         |                  |                  |              |
 * | A1, 21     | A1               |  PB08  |  A1             | EXTINT[8]   | *AIN[2]                         |                  |  SERCOM4/PAD[0]  |  TC0/WO[0]   |
 * | A2, 22     | A2               |  PB09  |  A2             | EXTINT[9]   | *AIN[3]            Y[15]        |                  |  SERCOM4/PAD[1]  |  TC0/WO[1]   |
 * | A3, 23     | A3               |  PA04  |  A3  PWM0_C0    | EXTINT[4]   | *AIN[4]    AIN[0]               |                  |  SERCOM0/PAD[0]  |  TCC0/WO[0]  |
 * | A4, 24     | A4               |  PA05  |  A4, PWM0_C1    | EXTINT[5]   | *AIN[5]    AIN[1]               |                  |  SERCOM0/PAD[1]  |  TCC0/WO[1]  |
 * | A5, 25     | %VBAT            |  PA07  |  A5, (%VBAT)    | EXTINT[7]   | *AIN[7]    AIN[3]               |                  |  SERCOM0/PAD[3]  |  TCC1/WO[1]  |
 * | A6, 26     | DIO5             |  PB02  |  A6 (DIO5)      | EXTINT[2]   | *AIN[10]                        |                  |  SERCOM5/PAD[0]  |              |
 * +------------+------------------+--------+-----------------+-------------+---------------------------------+------------------+------------------+--------------+-------------
 * |            | SPI (RFM,FLASH)  |        |                 |             |                                 |                  |                  |              |
 * +------------+------------------+--------+-----------------+-------------+---------------------------------+------------------+------------------+--------------+-------------
 * | 27         | SCK              |  PB11  |  SCK            | EXTINT[11]  |                    Y[3]         |                  | *SERCOM4/PAD[3]  |  TC1/WO[1]   |  TCC0/WO[5]
 * | 28         | MOSI             |  PB10  |  MOSI           | EXTINT[10]  |                    Y[2]         |                  | *SERCOM4/PAD[2]  |  TC1/WO[0]   |  TCC0/WO[4]
 * | 29         | MISO             |  PA12  |  MISO           | EXTINT[12]  |                                 |  SERCOM2/PAD[0]  | *SERCOM4/PAD[0]  |  TCC2/WO[0]  |  TCC0/WO[6]
 * +------------+------------------+--------+-----------------+-------------+---------------------------------+------------------+------------------+--------------+-------------
 * |            | AREF             |        |                 |             |                                 |                  |                  |              |
 * +------------+------------------+--------+-----------------+-------------+---------------------------------+------------------+------------------+--------------+-------------
 * | 30         | VREFa            |  PA03  |                 | EXTINT[3]   |                    Y[1]         |                  |                  |              |
 * +------------+------------------+--------+-----------------+-------------+---------------------------------+------------------+------------------+--------------+-------------
 * |            | LEDS USB         |        |                 |             |                                 |                  |                  |              |
 * +------------+------------------+--------+-----------------+-------------+---------------------------------+------------------+------------------+--------------+-------------
 * | 31         |                  |  PB03  |  RX LED         | EXTINT[3]   |  AIN[11]                        |                  |  SERCOM5/PAD[1]  |              |
 * | 32         |                  |  PA27  |  TX LED         | EXTINT[15]  |                                 |                  |                  |              |
 * +------------+------------------+--------+-----------------+-------------+---------------------------------+------------------+------------------+--------------+-------------
 * |            | USB              |        |                 |             |                                 |                  |                  |              |
 * +------------+------------------+--------+-----------------+-------------+---------------------------------+------------------+------------------+--------------+-------------
 * | 33         |                  |  PA24  |  USB- (DM)      | EXTINT[12]  |                                 |  SERCOM3/PAD[2]  |  SERCOM5/PAD[2]  |  TC1/WO[0]   |  TCC1/WO[2]
 * | 34         |                  |  PA25  |  USB+ (DP)      | EXTINT[13]  |                                 |  SERCOM3/PAD[3]  |  SERCOM5/PAD[3]  |  TC1/WO[1]   |  TCC1/WO[3]
 * +------------+------------------+--------+-----------------+-------------+---------------------------------+------------------+------------------+--------------+-------------
 * 
*/

#include "variant.h"

/*
 * Pins descriptions
 */
const PinDescription g_APinDescription[]=
{
  // 0..19 - Digital pins
  // ----------------------
  // 0,1 (UART-Serial, ext11, ext10)
  { PORTA, 11, PIO_MULTI, (PER_ATTR_DRIVE_STRONG|PER_ATTR_SERCOM_STD), (PIN_ATTR_ADC|PIN_ATTR_DIGITAL|PIN_ATTR_SERCOM|PIN_ATTR_EXTINT), NOT_ON_TIMER, ADC_Channel19, EXTERNAL_INT_11, GCLK_CCL_NONE }, // RX: SERCOM0/PAD[3]
  { PORTA, 10, PIO_MULTI, (PER_ATTR_DRIVE_STRONG|PER_ATTR_SERCOM_STD), (PIN_ATTR_ADC|PIN_ATTR_DIGITAL|PIN_ATTR_SERCOM|PIN_ATTR_EXTINT), NOT_ON_TIMER, ADC_Channel18, EXTERNAL_INT_10, GCLK_CCL_NONE }, // TX: SERCOM0/PAD[2]

  // 2 - BUILT-IN LED (PWM, ext15)
  { PORTA, 15, PIO_MULTI, (PER_ATTR_DRIVE_STRONG|PER_ATTR_TIMER_ALT), (PIN_ATTR_DIGITAL|PIN_ATTR_TIMER|PIN_ATTR_EXTINT), TCC0_CH5, No_ADC_Channel, EXTERNAL_INT_15, GCLK_CCL_NONE },

  // 3,4 (UART-Serial, ext7, ext6)
  { PORTB, 23, PIO_MULTI, (PER_ATTR_DRIVE_STRONG|PER_ATTR_SERCOM_ALT), (PIN_ATTR_DIGITAL|PIN_ATTR_SERCOM|PIN_ATTR_EXTINT), NOT_ON_TIMER, No_ADC_Channel, EXTERNAL_INT_7, GCLK_CCL_NONE }, // RX: SERCOM5/PAD[3]
  { PORTB, 22, PIO_MULTI, (PER_ATTR_DRIVE_STRONG|PER_ATTR_SERCOM_ALT), (PIN_ATTR_DIGITAL|PIN_ATTR_SERCOM|PIN_ATTR_EXTINT), NOT_ON_TIMER, No_ADC_Channel, EXTERNAL_INT_6, GCLK_CCL_NONE }, // TX: SERCOM5/PAD[2]

  // 5,6 (PWM, ext4, ext3)
  { PORTA, 20, PIO_MULTI, (PER_ATTR_DRIVE_STRONG|PER_ATTR_TIMER_ALT), (PIN_ATTR_DIGITAL|PIN_ATTR_TIMER|PIN_ATTR_EXTINT), TCC0_CH6, No_ADC_Channel, EXTERNAL_INT_4, GCLK_CCL_NONE },
  { PORTA, 19, PIO_MULTI, (PER_ATTR_DRIVE_STRONG|PER_ATTR_TIMER_ALT), (PIN_ATTR_DIGITAL|PIN_ATTR_TIMER|PIN_ATTR_EXTINT), TCC0_CH3, No_ADC_Channel, EXTERNAL_INT_3, GCLK_CCL_NONE },

  // 7,8 (I2C_CRYPTO)
  { PORTA, 22, PIO_MULTI, (PER_ATTR_DRIVE_STD|PER_ATTR_SERCOM_STD), (PIN_ATTR_DIGITAL|PIN_ATTR_SERCOM), NOT_ON_TIMER, No_ADC_Channel, EXTERNAL_INT_NONE, GCLK_CCL_NONE }, // SDA: SERCOM3/PAD[0]
  { PORTA, 23, PIO_MULTI, (PER_ATTR_DRIVE_STD|PER_ATTR_SERCOM_STD), (PIN_ATTR_DIGITAL|PIN_ATTR_SERCOM), NOT_ON_TIMER, No_ADC_Channel, EXTERNAL_INT_NONE, GCLK_CCL_NONE }, // SCL: SERCOM3/PAD[1]

  // 9,10 (PWM, SWDIO, SWCLK)
  { PORTA, 31, PIO_MULTI, (PER_ATTR_DRIVE_STRONG|PER_ATTR_TIMER_STD), (PIN_ATTR_DIGITAL|PIN_ATTR_TIMER), TCC1_CH1, No_ADC_Channel, EXTERNAL_INT_NONE, GCLK_CCL_NONE }, // SWDIO
  { PORTA, 30, PIO_MULTI, (PER_ATTR_DRIVE_STRONG|PER_ATTR_TIMER_STD), (PIN_ATTR_DIGITAL|PIN_ATTR_TIMER), TCC1_CH0, No_ADC_Channel, EXTERNAL_INT_NONE, GCLK_CCL_NONE }, // SWCLK

  // 11 (VBAT_EN)
  { PORTA,  6, PIO_MULTI, PER_ATTR_DRIVE_STRONG, (PIN_ATTR_ADC|PIN_ATTR_DIGITAL), NOT_ON_TIMER, ADC_Channel6, EXTERNAL_INT_NONE, GCLK_CCL_NONE },

  // 12..19 "Unaccessible" pins (RF_DIO0, RF_CS, RF_RST, FLASH_CS, FLASH_EN, CRYPTO_EN, TEMP&HUMI_I2C_SDA, TEMP&HUMI_I2C_SCL)
  { PORTA, 18, PIO_MULTI, (PER_ATTR_DRIVE_STD|PER_ATTR_TIMER_ALT), (PIN_ATTR_DIGITAL|PIN_ATTR_TIMER|PIN_ATTR_EXTINT), TCC0_CH2, No_ADC_Channel, EXTERNAL_INT_2, GCLK_CCL_NONE },
  { PORTA,  8, PIO_MULTI, (PER_ATTR_DRIVE_STD|PER_ATTR_TIMER_ALT), (PIN_ATTR_ADC|PIN_ATTR_DIGITAL|PIN_ATTR_TIMER), TCC1_CH2, ADC_Channel16, EXTERNAL_INT_NONE, GCLK_CCL_NONE },
  { PORTA,  9, PIO_MULTI, (PER_ATTR_DRIVE_STD|PER_ATTR_TIMER_ALT), (PIN_ATTR_ADC|PIN_ATTR_DIGITAL|PIN_ATTR_TIMER), TCC1_CH3, ADC_Channel17, EXTERNAL_INT_NONE, GCLK_CCL_NONE },
  { PORTA, 13, PIO_MULTI, (PER_ATTR_DRIVE_STD|PER_ATTR_TIMER_ALT), (PIN_ATTR_DIGITAL|PIN_ATTR_TIMER), TCC0_CH7, No_ADC_Channel, EXTERNAL_INT_NONE, GCLK_CCL_NONE },
  { PORTA, 14, PIO_MULTI, (PER_ATTR_DRIVE_STRONG|PER_ATTR_TIMER_ALT), (PIN_ATTR_DIGITAL|PIN_ATTR_TIMER), TCC0_CH4, No_ADC_Channel, EXTERNAL_INT_NONE, GCLK_CCL_NONE },
  { PORTA, 21, PIO_MULTI, PER_ATTR_DRIVE_STRONG, PIN_ATTR_DIGITAL, NOT_ON_TIMER, No_ADC_Channel, EXTERNAL_INT_NONE, GCLK_CCL_NONE },
  { PORTA, 16, PIO_MULTI, (PER_ATTR_DRIVE_STD|PER_ATTR_SERCOM_STD), (PIN_ATTR_DIGITAL|PIN_ATTR_SERCOM|PIN_ATTR_EXTINT), NOT_ON_TIMER, No_ADC_Channel, EXTERNAL_INT_0, GCLK_CCL_NONE }, // SDA: SERCOM1/PAD[0]
  { PORTA, 17, PIO_MULTI, (PER_ATTR_DRIVE_STD|PER_ATTR_SERCOM_STD), (PIN_ATTR_DIGITAL|PIN_ATTR_SERCOM|PIN_ATTR_EXTINT), NOT_ON_TIMER, No_ADC_Channel, EXTERNAL_INT_1, GCLK_CCL_NONE }, // SCL: SERCOM1/PAD[1]
  
  // 20..26 - Analog pins (A0..A6)
  // --------------------
  { PORTA,  2, PIO_MULTI, PER_ATTR_DRIVE_STRONG, (PIN_ATTR_ADC|PIN_ATTR_DAC|PIN_ATTR_DIGITAL), NOT_ON_TIMER, ADC_Channel0, EXTERNAL_INT_NONE, GCLK_CCL_NONE }, // ADC/AIN[0]
  { PORTB,  8, PIO_MULTI, PER_ATTR_DRIVE_STRONG, (PIN_ATTR_ADC|PIN_ATTR_DIGITAL|PIN_ATTR_EXTINT), NOT_ON_TIMER, ADC_Channel2, EXTERNAL_INT_8, GCLK_CCL_NONE }, // ADC/AIN[2]
  { PORTB,  9, PIO_MULTI, PER_ATTR_DRIVE_STRONG, (PIN_ATTR_ADC|PIN_ATTR_DIGITAL|PIN_ATTR_EXTINT), NOT_ON_TIMER, ADC_Channel3, EXTERNAL_INT_9, GCLK_CCL_NONE }, // ADC/AIN[3]
  { PORTA,  4, PIO_MULTI, (PER_ATTR_DRIVE_STRONG|PER_ATTR_TIMER_STD), (PIN_ATTR_ADC|PIN_ATTR_DIGITAL|PIN_ATTR_TIMER), TCC0_CH0, ADC_Channel4, EXTERNAL_INT_NONE, GCLK_CCL_NONE }, // ADC/AIN[4]
  { PORTA,  5, PIO_MULTI, (PER_ATTR_DRIVE_STRONG|PER_ATTR_TIMER_STD), (PIN_ATTR_ADC|PIN_ATTR_DIGITAL|PIN_ATTR_TIMER|PIN_ATTR_EXTINT), TCC0_CH1, ADC_Channel5, EXTERNAL_INT_5, GCLK_CCL_NONE }, // ADC/AIN[5]
  { PORTA,  7, PIO_MULTI, PER_ATTR_DRIVE_STRONG, (PIN_ATTR_ADC|PIN_ATTR_DIGITAL), NOT_ON_TIMER, ADC_Channel7, EXTERNAL_INT_NONE, GCLK_CCL_NONE }, // ADC/AIN[7]
  { PORTB,  2, PIO_MULTI, PER_ATTR_DRIVE_STRONG, (PIN_ATTR_ADC|PIN_ATTR_DIGITAL), NOT_ON_TIMER, ADC_Channel10, EXTERNAL_INT_NONE, GCLK_CCL_NONE}, // ADC/AIN[10]

  // 27..29 - SPI pins (ICSP:SCK, MOSI, MISO)
  // ----------------------
  { PORTB, 11, PIO_MULTI, (PER_ATTR_DRIVE_STD|PER_ATTR_SERCOM_ALT), (PIN_ATTR_DIGITAL|PIN_ATTR_SERCOM), NOT_ON_TIMER, No_ADC_Channel, EXTERNAL_INT_NONE, GCLK_CCL_NONE }, // SCK: SERCOM4/PAD[3]
  { PORTB, 10, PIO_MULTI, (PER_ATTR_DRIVE_STD|PER_ATTR_SERCOM_ALT), (PIN_ATTR_DIGITAL|PIN_ATTR_SERCOM), NOT_ON_TIMER, No_ADC_Channel, EXTERNAL_INT_NONE, GCLK_CCL_NONE }, // MOSI: SERCOM4/PAD[2]
  { PORTA, 12, PIO_MULTI, (PER_ATTR_DRIVE_STD|PER_ATTR_SERCOM_ALT), (PIN_ATTR_DIGITAL|PIN_ATTR_SERCOM|PIN_ATTR_EXTINT), NOT_ON_TIMER, No_ADC_Channel, EXTERNAL_INT_12, GCLK_CCL_NONE }, // MISO: SERCOM4/PAD[0]

  // 30 (AREF)
  { PORTA,  3, PIO_MULTI, PER_ATTR_DRIVE_STRONG, (PIN_ATTR_REF|PIN_ATTR_ADC|PIN_ATTR_DIGITAL), NOT_ON_TIMER, ADC_Channel1, EXTERNAL_INT_NONE, GCLK_CCL_NONE }, // VREF

  // 31,32 - RX/TX LEDS (PB03/PA27)
  // --------------------
  { PORTB,  3, PIO_MULTI, PER_ATTR_DRIVE_STD, PIN_ATTR_DIGITAL, NOT_ON_TIMER, No_ADC_Channel, EXTERNAL_INT_NONE, GCLK_CCL_NONE }, // used as output only
  { PORTA, 27, PIO_MULTI, PER_ATTR_DRIVE_STD, PIN_ATTR_DIGITAL, NOT_ON_TIMER, No_ADC_Channel, EXTERNAL_INT_NONE, GCLK_CCL_NONE }, // used as output only

  // 33,34 - USB
  // --------------------
  { PORTA, 24, PIO_COM, PER_ATTR_DRIVE_STRONG, (PIN_ATTR_DIGITAL|PIN_ATTR_COM), NOT_ON_TIMER, No_ADC_Channel, EXTERNAL_INT_NONE, GCLK_CCL_NONE }, // USB/DM
  { PORTA, 25, PIO_COM, PER_ATTR_DRIVE_STRONG, (PIN_ATTR_DIGITAL|PIN_ATTR_COM), NOT_ON_TIMER, No_ADC_Channel, EXTERNAL_INT_NONE, GCLK_CCL_NONE }, // USB/DP

} ;

const void* g_apTCInstances[TCC_INST_NUM+TC_INST_NUM]={ TCC0, TCC1, TCC2, TC0, TC1, TC4 } ;

// Multi-serial objects instantiation
SERCOM sercom0( SERCOM0 ) ;
SERCOM sercom1( SERCOM1 ) ;
SERCOM sercom2( SERCOM2 ) ;
SERCOM sercom3( SERCOM3 ) ;
SERCOM sercom4( SERCOM4 ) ;
SERCOM sercom5( SERCOM5 ) ;

Uart Serial0( SERCOM_INSTANCE_SERIAL0, PIN_SERIAL0_RX, PIN_SERIAL0_TX, PAD_SERIAL0_RX, PAD_SERIAL0_TX ) ;
Uart Serial1( SERCOM_INSTANCE_SERIAL1, PIN_SERIAL1_RX, PIN_SERIAL1_TX, PAD_SERIAL1_RX, PAD_SERIAL1_TX ) ;

void SERCOM0_Handler()
{
  Serial0.IrqHandler();
}


void SERCOM5_Handler()
{
   Serial1.IrqHandler();
}
